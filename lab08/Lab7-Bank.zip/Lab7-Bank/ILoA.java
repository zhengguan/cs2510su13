
// Represents a List of Accounts
public interface ILoA{

}

