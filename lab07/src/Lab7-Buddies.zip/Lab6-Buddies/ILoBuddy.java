
// represents a list of Person's buddies
interface ILoBuddy {

}
